import type { Article, InsertArticle } from "@shared/schema";

export interface NewsAPIArticle {
  title: string;
  description?: string;
  content?: string;
  url: string;
  urlToImage?: string;
  source: {
    name: string;
  };
  author?: string;
  publishedAt: string;
}

export interface NewsAPIResponse {
  status: string;
  totalResults: number;
  articles: NewsAPIArticle[];
}

export class NewsService {
  private apiKey: string;
  private baseUrl = "https://newsapi.org/v2";

  constructor() {
    this.apiKey = process.env.NEWS_API_KEY || process.env.NEWSAPI_KEY || "";
    if (!this.apiKey) {
      console.warn("News API key not found. Please set NEWS_API_KEY or NEWSAPI_KEY environment variable.");
    }
  }

  private mapNewsAPIToArticle(newsArticle: NewsAPIArticle, category: string = "general"): InsertArticle {
    return {
      title: newsArticle.title,
      description: newsArticle.description || null,
      content: newsArticle.content || null,
      url: newsArticle.url,
      imageUrl: newsArticle.urlToImage || null,
      category,
      source: newsArticle.source.name,
      author: newsArticle.author || null,
      publishedAt: new Date(newsArticle.publishedAt),
    };
  }

  async getTopHeadlines(country: string = "us", category?: string, pageSize: number = 20): Promise<InsertArticle[]> {
    if (!this.apiKey) {
      throw new Error("News API key is required");
    }

    try {
      const params = new URLSearchParams({
        apiKey: this.apiKey,
        country,
        pageSize: pageSize.toString(),
      });

      if (category) {
        params.append("category", category);
      }

      const response = await fetch(`${this.baseUrl}/top-headlines?${params}`);
      
      if (!response.ok) {
        throw new Error(`News API error: ${response.status} ${response.statusText}`);
      }

      const data: NewsAPIResponse = await response.json();
      
      if (data.status !== "ok") {
        throw new Error(`News API returned error status: ${data.status}`);
      }

      return data.articles
        .filter(article => article.title && article.title !== "[Removed]")
        .map(article => this.mapNewsAPIToArticle(article, category || "general"));
    } catch (error) {
      console.error("Error fetching news:", error);
      throw error;
    }
  }

  async searchNews(query: string, pageSize: number = 20): Promise<InsertArticle[]> {
    if (!this.apiKey) {
      throw new Error("News API key is required");
    }

    try {
      const params = new URLSearchParams({
        apiKey: this.apiKey,
        q: query,
        pageSize: pageSize.toString(),
        sortBy: "publishedAt",
      });

      const response = await fetch(`${this.baseUrl}/everything?${params}`);
      
      if (!response.ok) {
        throw new Error(`News API error: ${response.status} ${response.statusText}`);
      }

      const data: NewsAPIResponse = await response.json();
      
      if (data.status !== "ok") {
        throw new Error(`News API returned error status: ${data.status}`);
      }

      return data.articles
        .filter(article => article.title && article.title !== "[Removed]")
        .map(article => this.mapNewsAPIToArticle(article, "search"));
    } catch (error) {
      console.error("Error searching news:", error);
      throw error;
    }
  }
}

export const newsService = new NewsService();
