import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { newsService } from "./services/newsService";
import { mockArticles } from "./mockData";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get top headlines
  app.get("/api/news/headlines", async (req, res) => {
    try {
      const { country = "us", category, limit = "20" } = req.query;
      
      const pageSize = Math.min(parseInt(limit as string) || 20, 100);
      
      // Try real API first, fallback to mock data if API fails
      try {
        const articles = await newsService.getTopHeadlines(
          country as string,
          category as string | undefined,
          pageSize
        );
        res.json(articles);
      } catch (apiError) {
        console.warn("News API failed, using mock data:", apiError);
        // Return mock data for demonstration with generated IDs
        const timestamp = Date.now();
        const filteredMockData = mockArticles.slice(0, pageSize).map((article, index) => ({
          ...article,
          id: `mock-${timestamp}-${index}`,
          createdAt: new Date()
        }));
        console.log("Returning mock data with IDs:", filteredMockData[0]?.id);
        res.json(filteredMockData);
      }
    } catch (error) {
      console.error("Error fetching headlines:", error);
      res.status(500).json({ 
        message: "Failed to fetch news headlines",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Search news
  app.get("/api/news/search", async (req, res) => {
    try {
      const { q, limit = "20" } = req.query;
      
      if (!q || typeof q !== "string") {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const pageSize = Math.min(parseInt(limit as string) || 20, 100);
      
      try {
        const articles = await newsService.searchNews(q, pageSize);
        res.json(articles);
      } catch (apiError) {
        console.warn("News API failed, using mock data for search:", apiError);
        // Filter mock data by search query
        const searchQuery = q.toLowerCase();
        const filteredMockData = mockArticles
          .filter(article => 
            article.title.toLowerCase().includes(searchQuery) ||
            (article.description && article.description.toLowerCase().includes(searchQuery))
          )
          .slice(0, pageSize)
          .map((article, index) => ({
            ...article,
            id: `mock-search-${Date.now()}-${index}`,
            createdAt: new Date()
          }));
        res.json(filteredMockData);
      }
    } catch (error) {
      console.error("Error searching news:", error);
      res.status(500).json({ 
        message: "Failed to search news",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get news by category
  app.get("/api/news/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const { limit = "20" } = req.query;
      
      const validCategories = ["business", "entertainment", "general", "health", "science", "sports", "technology"];
      
      if (!validCategories.includes(category)) {
        return res.status(400).json({ 
          message: "Invalid category",
          validCategories
        });
      }
      
      const pageSize = Math.min(parseInt(limit as string) || 20, 100);
      
      try {
        const articles = await newsService.getTopHeadlines("us", category, pageSize);
        res.json(articles);
      } catch (apiError) {
        console.warn("News API failed, using mock data:", apiError);
        // Filter mock data by category with generated IDs
        const timestamp = Date.now();
        const filteredMockData = mockArticles
          .filter(article => article.category === category)
          .slice(0, pageSize)
          .map((article, index) => ({
            ...article,
            id: `mock-${category}-${timestamp}-${index}`,
            createdAt: new Date()
          }));
        console.log("Returning category mock data with IDs:", filteredMockData[0]?.id);
        res.json(filteredMockData);
      }
    } catch (error) {
      console.error("Error fetching category news:", error);
      res.status(500).json({ 
        message: "Failed to fetch category news",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
