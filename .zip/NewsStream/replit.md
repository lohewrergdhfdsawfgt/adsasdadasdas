# Russian News Website

## Overview

This is a Russian news website built with React, Express, and TypeScript. The application fetches news articles from external APIs and displays them in a clean, minimalistic interface. The site features a Russian-language interface with modern design components from shadcn/ui, using Tailwind CSS for styling and Roboto Condensed font for typography.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite for build tooling
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Typography**: Roboto Condensed font family loaded from Google Fonts

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Structure**: RESTful endpoints under `/api` namespace
- **News Service**: Service layer for interacting with NewsAPI external service
- **Storage**: In-memory storage implementation with interface for future database integration
- **Middleware**: Custom logging middleware for API request tracking

### Database Schema
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Tables**: 
  - `users` table with id, username, password fields
  - `articles` table with comprehensive news article fields (title, description, content, url, imageUrl, category, source, author, publishedAt, createdAt)
- **Database Provider**: Neon Database (@neondatabase/serverless)

### External Dependencies

#### Third-party Services
- **NewsAPI**: External news service for fetching headlines and search functionality
- **Neon Database**: PostgreSQL-compatible serverless database

#### Key Libraries
- **UI Components**: Extensive Radix UI component collection (@radix-ui/*)
- **Form Handling**: React Hook Form with Hookform Resolvers for validation
- **Data Fetching**: TanStack React Query for server state management
- **Styling**: Tailwind CSS with class-variance-authority and clsx for dynamic styling
- **Date Handling**: date-fns for date formatting and manipulation
- **Carousel**: Embla Carousel for image/content carousels
- **Database**: Drizzle ORM with Drizzle-Zod for schema validation
- **Session Management**: connect-pg-simple for PostgreSQL session storage

#### Development Tools
- **Build**: Vite for frontend bundling, esbuild for backend compilation
- **TypeScript**: Full TypeScript setup with path aliases
- **Development**: tsx for running TypeScript files directly
- **Replit Integration**: Custom Replit plugins for development environment

The application follows a clean separation of concerns with shared schema definitions, modular component architecture, and a service-based backend design that allows for easy extension and maintenance.