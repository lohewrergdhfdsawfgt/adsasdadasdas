import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Article from "@/pages/article";
import { CategoryPage } from "@/pages/category";
import { PlaceholderPage } from "@/pages/placeholder";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/article/:id" component={Article} />
      <Route path="/category/:category" component={CategoryPage} />
      <Route path="/twitter" component={PlaceholderPage} />
      <Route path="/facebook" component={PlaceholderPage} />
      <Route path="/contacts" component={PlaceholderPage} />
      <Route path="/privacy" component={PlaceholderPage} />
      <Route path="/about" component={PlaceholderPage} />
      <Route path="/advertising" component={PlaceholderPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
