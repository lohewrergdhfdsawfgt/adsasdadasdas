import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, AlertTriangle } from "lucide-react";
import Header from "@/components/header";
import Footer from "@/components/footer";

export function PlaceholderPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <Card className="mx-auto max-w-md">
            <CardContent className="pt-8 pb-8">
              <div className="flex justify-center mb-6">
                <AlertTriangle className="h-16 w-16 text-yellow-500" data-testid="icon-warning" />
              </div>
              
              <h1 className="text-2xl font-bold text-gray-900 mb-4" data-testid="text-title">
                Упс! Разработчик забыл вписать информацию.
              </h1>
              
              <p className="text-gray-600 mb-6" data-testid="text-description">
                Очень извиняемся!
              </p>
              
              <Button
                onClick={() => setLocation("/")}
                className="w-full"
                data-testid="button-home"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Вернуться на главную
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}