import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, RefreshCw } from "lucide-react";
import NewsGrid from "@/components/news-grid";
import Header from "@/components/header";
import Footer from "@/components/footer";
import type { Article } from "@shared/schema";

export function CategoryPage() {
  const { category } = useParams<{ category: string }>();
  const [, setLocation] = useLocation();

  const categoryNames: Record<string, string> = {
    business: "Бизнес",
    entertainment: "Развлечения", 
    general: "Общие новости",
    health: "Здоровье",
    science: "Наука",
    sports: "Спорт",
    technology: "Технологии"
  };

  const {
    data: articles,
    isLoading,
    error,
    refetch,
  } = useQuery<Article[]>({
    queryKey: [`/api/news/category/${category}?limit=20`],
    staleTime: 5 * 60 * 1000, // 5 minutes
    enabled: !!category,
  });

  const categoryTitle = categoryNames[category || ""] || "Неизвестная категория";

  const renderError = (error: Error | null, refetchFn: () => void) => {
    if (!error) return null;
    
    return (
      <Alert className="mb-6 border-red-200 bg-red-50" data-testid="alert-error">
        <AlertDescription className="flex items-center justify-between">
          <span>Ошибка загрузки новостей: {error.message}</span>
          <Button
            onClick={refetchFn}
            variant="outline"
            size="sm"
            className="ml-4"
            data-testid="button-retry"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Повторить
          </Button>
        </AlertDescription>
      </Alert>
    );
  };

  const renderLoadingSkeleton = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: 9 }).map((_, i) => (
        <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden" data-testid={`skeleton-${i}`}>
          <Skeleton className="h-48 w-full" />
          <div className="p-4">
            <Skeleton className="h-6 w-3/4 mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center mb-8">
          <Button
            onClick={() => setLocation("/")}
            variant="outline"
            className="mr-4"
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Назад
          </Button>
          <h1 className="text-4xl font-bold text-[var(--primary)]" data-testid="text-category-title">
            {categoryTitle}
          </h1>
        </div>

        {renderError(error as Error | null, refetch)}

        {isLoading ? (
          renderLoadingSkeleton()
        ) : articles && articles.length > 0 ? (
          <NewsGrid articles={articles} />
        ) : (
          <Alert data-testid="alert-no-articles">
            <AlertDescription>
              В категории "{categoryTitle}" пока нет новостей. Попробуйте выбрать другую категорию или обновите страницу.
            </AlertDescription>
          </Alert>
        )}
      </main>

      <Footer />
    </div>
  );
}