import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, ExternalLink, Calendar, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/header";
import Footer from "@/components/footer";

interface ArticleData {
  title: string;
  description?: string;
  content?: string;
  url: string;
  imageUrl?: string;
  category?: string;
  source?: string;
  author?: string;
  publishedAt: string;
}

export default function Article() {
  const [, setLocation] = useLocation();
  const [article, setArticle] = useState<ArticleData | null>(null);

  useEffect(() => {
    // Получаем данные статьи из URL параметров или localStorage
    const urlParams = new URLSearchParams(window.location.search);
    const articleData = urlParams.get('data');
    
    if (articleData) {
      try {
        const parsedData = JSON.parse(decodeURIComponent(articleData));
        setArticle(parsedData);
      } catch (error) {
        console.error('Error parsing article data:', error);
        setLocation('/');
      }
    } else {
      setLocation('/');
    }
  }, [setLocation]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      politics: "bg-[var(--accent)] text-white",
      business: "bg-green-500 text-white",
      technology: "bg-purple-500 text-white",
      sports: "bg-orange-500 text-white",
      science: "bg-purple-500 text-white",
      health: "bg-red-500 text-white",
      entertainment: "bg-pink-500 text-white",
      general: "bg-blue-600 text-white",
    };
    return colors[category?.toLowerCase() || "general"] || colors.general;
  };

  const getCategoryLabel = (category: string) => {
    const labels: Record<string, string> = {
      politics: "Политика",
      business: "Экономика",
      technology: "Технологии",
      sports: "Спорт",
      science: "Наука",
      health: "Здоровье",
      entertainment: "Культура",
      general: "Общее",
    };
    return labels[category?.toLowerCase() || "general"] || "Новости";
  };

  if (!article) {
    return (
      <div className="min-h-screen bg-[var(--news-bg-light)]">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-[var(--secondary)]">Загрузка статьи...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--news-bg-light)]">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Кнопка "Назад" */}
        <Button
          variant="outline"
          onClick={() => setLocation('/')}
          className="mb-6"
          data-testid="button-back"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Назад к новостям
        </Button>

        {/* Основная статья */}
        <article className="bg-white rounded-lg shadow-lg overflow-hidden">
          {/* Заголовок и метаданные */}
          <div className="p-8">
            <div className="flex flex-wrap items-center gap-4 mb-6">
              {article.category && (
                <Badge className={getCategoryColor(article.category)}>
                  {getCategoryLabel(article.category)}
                </Badge>
              )}
              <div className="flex items-center text-[var(--secondary)] text-sm">
                <Calendar className="w-4 h-4 mr-1" />
                {formatDate(article.publishedAt)}
              </div>
              {article.author && (
                <div className="flex items-center text-[var(--secondary)] text-sm">
                  <User className="w-4 h-4 mr-1" />
                  {article.author}
                </div>
              )}
            </div>

            <h1 
              className="text-3xl md:text-4xl font-bold text-[var(--primary)] mb-6 leading-tight"
              data-testid="text-article-title"
            >
              {article.title}
            </h1>

            {article.description && (
              <p 
                className="text-xl text-[var(--secondary)] mb-8 leading-relaxed"
                data-testid="text-article-description"
              >
                {article.description}
              </p>
            )}
          </div>

          {/* Изображение */}
          {article.imageUrl && (
            <div className="px-8 mb-8">
              <img
                src={article.imageUrl}
                alt={article.title}
                className="w-full h-96 object-cover rounded-lg"
                data-testid="img-article-main"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                }}
              />
            </div>
          )}

          {/* Контент статьи */}
          <div className="px-8 pb-8">
            {article.content && (
              <div className="prose prose-lg max-w-none">
                <p 
                  className="text-[var(--secondary)] leading-relaxed text-lg mb-8"
                  data-testid="text-article-content"
                >
                  {article.content.replace(/\[.*?\]/g, '')}
                </p>
              </div>
            )}

            {/* Источник */}
            {article.source && (
              <div className="border-t border-[var(--news-border-light)] pt-6 mb-6">
                <p className="text-sm text-[var(--secondary)]">
                  Источник: <span className="font-medium">{article.source}</span>
                </p>
              </div>
            )}

            {/* Ссылка на оригинальную статью */}
            <div className="flex justify-center">
              <a
                href={article.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 bg-[var(--accent)] text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
                data-testid="link-original-article"
              >
                Читать на оригинальном сайте
                <ExternalLink className="w-4 h-4 ml-2" />
              </a>
            </div>
          </div>
        </article>
      </main>

      <Footer />
    </div>
  );
}