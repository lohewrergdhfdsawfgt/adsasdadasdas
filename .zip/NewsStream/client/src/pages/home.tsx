import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import FeaturedNews from "@/components/featured-news";
import NewsGrid from "@/components/news-grid";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, RefreshCw } from "lucide-react";
import type { Article } from "@shared/schema";

export default function Home() {
  const {
    data: headlines,
    isLoading: headlinesLoading,
    error: headlinesError,
    refetch: refetchHeadlines,
  } = useQuery<Article[]>({
    queryKey: ["/api/news/headlines"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const {
    data: otherNews,
    isLoading: otherNewsLoading,
    error: otherNewsError,
    refetch: refetchOtherNews,
  } = useQuery<Article[]>({
    queryKey: ["/api/news/category/general?limit=12"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const handleRefreshAll = () => {
    refetchHeadlines();
    refetchOtherNews();
  };

  const renderError = (error: Error | null, retryFn: () => void) => {
    if (!error) return null;
    
    return (
      <Alert className="mb-6" data-testid="error-alert">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription className="flex items-center justify-between">
          <span>
            {error.message.includes("API key") 
              ? "Для получения новостей требуется API ключ NewsAPI. Пожалуйста, добавьте NEWS_API_KEY в переменные окружения."
              : `Ошибка загрузки новостей: ${error.message}`
            }
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={retryFn}
            className="ml-4"
            data-testid="button-retry"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Повторить
          </Button>
        </AlertDescription>
      </Alert>
    );
  };

  const renderLoadingSkeleton = (count: number) => (
    <div className="space-y-6">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-white rounded-lg shadow-md p-6" data-testid={`skeleton-${i}`}>
          <Skeleton className="h-6 w-32 mb-4" />
          <Skeleton className="h-8 w-full mb-4" />
          <Skeleton className="h-64 w-full rounded-lg mb-4" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      ))}
    </div>
  );

  const renderGridLoadingSkeleton = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden" data-testid={`grid-skeleton-${i}`}>
          <Skeleton className="h-48 w-full" />
          <div className="p-6">
            <Skeleton className="h-4 w-20 mb-3" />
            <Skeleton className="h-6 w-full mb-3" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen bg-[var(--news-bg-light)]">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header with refresh button */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-[var(--news-text-dark)]" data-testid="text-main-title">
            Свежие Новости
          </h1>
          <Button
            variant="outline"
            onClick={handleRefreshAll}
            disabled={headlinesLoading || otherNewsLoading}
            data-testid="button-refresh-all"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${(headlinesLoading || otherNewsLoading) ? 'animate-spin' : ''}`} />
            Обновить
          </Button>
        </div>

        {/* Featured News Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-[var(--primary)] mb-8" data-testid="text-featured-title">
            Главные новости дня
          </h2>
          
          {renderError(headlinesError as Error | null, refetchHeadlines)}
          
          {headlinesLoading ? (
            renderLoadingSkeleton(2)
          ) : headlines && headlines.length > 0 ? (
            <FeaturedNews articles={headlines.slice(0, 2)} />
          ) : (
            <Alert data-testid="alert-no-featured">
              <AlertDescription>
                Главные новости пока не загружены. Попробуйте обновить страницу.
              </AlertDescription>
            </Alert>
          )}
        </section>

        {/* Other News Section */}
        <section>
          <h2 className="text-3xl font-bold text-[var(--primary)] mb-8" data-testid="text-other-title">
            Другие новости
          </h2>
          
          {renderError(otherNewsError as Error | null, refetchOtherNews)}
          
          {otherNewsLoading ? (
            renderGridLoadingSkeleton()
          ) : otherNews && otherNews.length > 0 ? (
            <NewsGrid articles={otherNews} />
          ) : (
            <Alert data-testid="alert-no-other">
              <AlertDescription>
                Дополнительные новости пока не загружены. Попробуйте обновить страницу.
              </AlertDescription>
            </Alert>
          )}
        </section>
      </main>

      <Footer />
    </div>
  );
}
