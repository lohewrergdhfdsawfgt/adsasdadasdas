import { Badge } from "@/components/ui/badge";
import { ExternalLink } from "lucide-react";
import { useLocation } from "wouter";
import type { Article } from "@shared/schema";

interface NewsCardProps {
  article: Article;
  variant?: "featured" | "grid";
}

export default function NewsCard({ article, variant = "grid" }: NewsCardProps) {
  const [, setLocation] = useLocation();

  const handleReadMore = () => {
    const articleData = encodeURIComponent(JSON.stringify({
      title: article.title,
      description: article.description,
      content: article.content,
      url: article.url,
      imageUrl: article.imageUrl,
      category: article.category,
      source: article.source,
      author: article.author,
      publishedAt: article.publishedAt
    }));
    setLocation(`/article?data=${articleData}`);
  };
  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return "менее часа назад";
    } else if (diffInHours < 24) {
      return `${diffInHours} ${diffInHours === 1 ? 'час' : diffInHours < 5 ? 'часа' : 'часов'} назад`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays} ${diffInDays === 1 ? 'день' : diffInDays < 5 ? 'дня' : 'дней'} назад`;
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      politics: "bg-[var(--accent)] text-white",
      business: "bg-green-500 text-white",
      technology: "bg-purple-500 text-white",
      sports: "bg-orange-500 text-white",
      science: "bg-purple-500 text-white",
      health: "bg-red-500 text-white",
      entertainment: "bg-pink-500 text-white",
      general: "bg-blue-600 text-white",
    };
    return colors[category.toLowerCase()] || colors.general;
  };

  const getCategoryLabel = (category: string) => {
    const labels: Record<string, string> = {
      politics: "Политика",
      business: "Экономика",
      technology: "Технологии",
      sports: "Спорт",
      science: "Наука",
      health: "Здоровье",
      entertainment: "Культура",
      general: "Общее",
    };
    return labels[category.toLowerCase()] || "Новости";
  };

  if (variant === "featured") {
    return (
      <article 
        className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 mb-8 overflow-hidden group"
        data-testid={`card-featured-${article.id}`}
      >
        {/* Заголовок новостей */}
        <div className="p-6 pb-4">
          <div className="flex items-center mb-3">
            <Badge className={getCategoryColor(article.category || "general")}>
              {getCategoryLabel(article.category || "general")}
            </Badge>
            <span className="text-[var(--secondary)] text-sm ml-4" data-testid={`text-time-${article.id}`}>
              {formatTimeAgo(new Date(article.publishedAt))}
            </span>
          </div>
          <h3 
            className="text-2xl font-bold text-[var(--primary)] mb-4 leading-tight hover:text-[var(--accent)] cursor-pointer transition-colors duration-200"
            data-testid={`text-title-${article.id}`}
          >
            {article.title}
          </h3>
        </div>
        
        {/* Картинка */}
        {article.imageUrl && (
          <div className="px-6 pb-4">
            <img
              src={article.imageUrl}
              alt={article.title}
              className="w-full h-64 object-cover rounded-lg"
              data-testid={`img-featured-${article.id}`}
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
              }}
            />
          </div>
        )}
        
        {/* Полные новости */}
        <div className="px-6 pb-6">
          {article.description && (
            <p className="text-[var(--secondary)] leading-relaxed mb-4" data-testid={`text-description-${article.id}`}>
              {article.description}
            </p>
          )}
          {article.content && (
            <p className="text-[var(--secondary)] leading-relaxed mb-4" data-testid={`text-content-${article.id}`}>
              {article.content.replace(/\[.*?\]/g, '').substring(0, 200)}...
            </p>
          )}
          <div className="flex gap-4 items-center">
            <button
              onClick={handleReadMore}
              className="inline-flex items-center text-[var(--accent)] hover:text-blue-700 font-medium transition-colors duration-200"
              data-testid={`button-read-more-${article.id}`}
            >
              Читать полностью
            </button>
            <a
              href={article.url || "#"}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center text-[var(--secondary)] hover:text-[var(--accent)] font-medium transition-colors duration-200"
              data-testid={`link-original-${article.id}`}
            >
              На сайте источника
              <ExternalLink className="w-4 h-4 ml-1" />
            </a>
          </div>
        </div>
      </article>
    );
  }

  // Grid variant
  return (
    <article 
      className="bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden group"
      data-testid={`card-grid-${article.id}`}
    >
      {/* Картинка */}
      {article.imageUrl && (
        <div className="relative overflow-hidden">
          <img
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
            data-testid={`img-grid-${article.id}`}
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
            }}
          />
          <div className="absolute top-4 left-4">
            <Badge className={getCategoryColor(article.category || "general")}>
              {getCategoryLabel(article.category || "general")}
            </Badge>
          </div>
        </div>
      )}
      
      {/* Заголовок новостей и Полные новости */}
      <div className="p-6">
        <div className="mb-3">
          <span className="text-[var(--secondary)] text-sm" data-testid={`text-grid-time-${article.id}`}>
            {formatTimeAgo(new Date(article.publishedAt))}
          </span>
        </div>
        <h3 
          className="text-lg font-bold text-[var(--primary)] mb-3 leading-tight group-hover:text-[var(--accent)] transition-colors duration-200"
          data-testid={`text-grid-title-${article.id}`}
        >
          {article.title}
        </h3>
        {article.description && (
          <p 
            className="text-[var(--secondary)] text-sm leading-relaxed mb-4"
            data-testid={`text-grid-description-${article.id}`}
          >
            {article.description.substring(0, 150)}...
          </p>
        )}
        <div className="flex gap-3 items-center">
          <button
            onClick={handleReadMore}
            className="text-[var(--accent)] hover:text-blue-700 font-medium text-sm transition-colors duration-200"
            data-testid={`button-grid-read-more-${article.id}`}
          >
            Подробнее →
          </button>
          <a
            href={article.url || "#"}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[var(--secondary)] hover:text-[var(--accent)] text-sm transition-colors duration-200"
            data-testid={`link-grid-original-${article.id}`}
          >
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </article>
  );
}
