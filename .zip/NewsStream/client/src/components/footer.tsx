import { Twitter, Facebook } from "lucide-react";
import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-[var(--primary)] text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <h3 className="text-xl font-bold mb-4" data-testid="text-footer-title">
              Новости
            </h3>
            <p className="text-gray-300 mb-4 leading-relaxed" data-testid="text-footer-description">
              Ваш надежный источник актуальной информации. Мы предоставляем свежие новости из всех сфер жизни общества.
            </p>
            <div className="flex space-x-4">
              <Link
                href="/twitter"
                className="text-gray-300 hover:text-white transition-colors duration-200"
                data-testid="link-twitter"
                aria-label="Twitter"
              >
                <Twitter className="w-6 h-6" />
              </Link>
              <Link
                href="/facebook"
                className="text-gray-300 hover:text-white transition-colors duration-200"
                data-testid="link-facebook"
                aria-label="Facebook"
              >
                <Facebook className="w-6 h-6" />
              </Link>
            </div>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-sections-title">
              Разделы
            </h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <Link
                  href="/category/general"
                  className="hover:text-white transition-colors duration-200"
                  data-testid="link-footer-politics"
                >
                  Политика
                </Link>
              </li>
              <li>
                <Link
                  href="/category/business"
                  className="hover:text-white transition-colors duration-200"
                  data-testid="link-footer-economy"
                >
                  Экономика
                </Link>
              </li>
              <li>
                <Link
                  href="/category/sports"
                  className="hover:text-white transition-colors duration-200"
                  data-testid="link-footer-sports"
                >
                  Спорт
                </Link>
              </li>
              <li>
                <Link
                  href="/category/technology"
                  className="hover:text-white transition-colors duration-200"
                  data-testid="link-footer-technology"
                >
                  Технологии
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-contacts-title">
              Контакты
            </h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <Link
                  href="/about"
                  className="hover:text-white transition-colors duration-200"
                  data-testid="link-about"
                >
                  О нас
                </Link>
              </li>
              <li>
                <Link
                  href="/advertising"
                  className="hover:text-white transition-colors duration-200"
                  data-testid="link-advertising"
                >
                  Реклама
                </Link>
              </li>
              <li>
                <Link
                  href="/contacts"
                  className="hover:text-white transition-colors duration-200"
                  data-testid="link-contacts"
                >
                  Контакты
                </Link>
              </li>
              <li>
                <Link
                  href="/privacy"
                  className="hover:text-white transition-colors duration-200"
                  data-testid="link-privacy"
                >
                  Политика конфиденциальности
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-600 mt-8 pt-8 text-center text-gray-300">
          <p data-testid="text-copyright">
            &copy; 2024 Новости. Все права защищены.
          </p>
        </div>
      </div>
    </footer>
  );
}
