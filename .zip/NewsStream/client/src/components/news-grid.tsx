import NewsCard from "./news-card";
import type { Article } from "@shared/schema";

interface NewsGridProps {
  articles: Article[];
}

export default function NewsGrid({ articles }: NewsGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="news-grid-container">
      {articles.map((article) => (
        <NewsCard key={article.id} article={article} variant="grid" />
      ))}
    </div>
  );
}
