import NewsCard from "./news-card";
import type { Article } from "@shared/schema";

interface FeaturedNewsProps {
  articles: Article[];
}

export default function FeaturedNews({ articles }: FeaturedNewsProps) {
  return (
    <div className="space-y-8" data-testid="featured-news-container">
      {articles.map((article) => (
        <NewsCard key={article.id} article={article} variant="featured" />
      ))}
    </div>
  );
}
