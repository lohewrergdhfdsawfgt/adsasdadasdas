import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="bg-white shadow-sm border-b border-[var(--news-border-light)] sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-[var(--primary)]" data-testid="text-logo">
              Новости
            </h1>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link
              href="/"
              className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
              data-testid="link-home"
            >
              Главная
            </Link>
            <Link
              href="/category/general"
              className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
              data-testid="link-politics"
            >
              Политика
            </Link>
            <Link
              href="/category/business"
              className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
              data-testid="link-economy"
            >
              Экономика
            </Link>
            <Link
              href="/category/sports"
              className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
              data-testid="link-sports"
            >
              Спорт
            </Link>
            <Link
              href="/category/technology"
              className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
              data-testid="link-technology"
            >
              Технологии
            </Link>
          </nav>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleMobileMenu}
              className="text-[var(--secondary)] hover:text-[var(--accent)]"
              data-testid="button-mobile-menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </Button>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-[var(--news-border-light)]" data-testid="nav-mobile">
            <div className="flex flex-col space-y-4">
              <Link
                href="/"
                className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
                data-testid="link-mobile-home"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Главная
              </Link>
              <Link
                href="/category/general"
                className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
                data-testid="link-mobile-politics"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Политика
              </Link>
              <Link
                href="/category/business"
                className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
                data-testid="link-mobile-economy"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Экономика
              </Link>
              <Link
                href="/category/sports"
                className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
                data-testid="link-mobile-sports"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Спорт
              </Link>
              <Link
                href="/category/technology"
                className="text-[var(--secondary)] hover:text-[var(--accent)] transition-colors duration-200 font-medium"
                data-testid="link-mobile-technology"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Технологии
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
